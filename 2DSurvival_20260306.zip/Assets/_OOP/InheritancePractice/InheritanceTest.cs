using UnityEngine;

public class InheritanceTest : MonoBehaviour
{
    [SerializeField] ColorChanger _colorChanager;
    [SerializeField] MonoBehaviour _monoBehaviour;
    [SerializeField] Object _object;

    private void Start()
    {

    }
}
