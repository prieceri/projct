using UnityEngine;

public class BWColorChanger : ColorChanger
{
    private void Update()
    {
        if(Input.GetKeyDown(KeyCode.W) == true)
        {
            ChangeColor(Color.white);
        }
        if(Input.GetKeyDown(KeyCode.B) == true)
        {
            ChangeColor(Color.black);
        }
    }
}
