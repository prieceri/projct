using UnityEngine;

public class AnyColorChanger : ColorChanger
{
    [SerializeField] Color _color;

    private void Update()
    {
        if(Input.GetKey(KeyCode.Space) == true)
        {
            ChangeColor(_color);
        }
    }
}
