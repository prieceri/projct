using UnityEngine;

public class RGBColorChanger : ColorChanger
{
    private void Update()
    {
        if(Input.GetKeyDown(KeyCode.Alpha1) == true)
        {
            ChangeColor(Color.red);
        }
        if(Input.GetKeyDown(KeyCode.Alpha2) == true)
        {
            ChangeColor(Color.green);
        }
        if(Input.GetKeyDown(KeyCode.Alpha3) == true)
        {
            ChangeColor(Color.blue);
        }
    }
}
