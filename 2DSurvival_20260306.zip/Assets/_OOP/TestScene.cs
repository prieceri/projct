using UnityEngine;

/*
Warrior의 체력 변경 이벤트를 WarriorHpBar가 적절하게 구독하게 만들어 주세요!  
*/

public class TestScene : MonoBehaviour
{
    [SerializeField] EventStudy _publisher;     // 이벤트 발행자
    [SerializeField] EventTest _subscriber;      // 이벤트 구독자

    [SerializeField] Warrior _warrior;
    [SerializeField] WarriorHpBar _hpBar;

    private void Start()
    {
        // 이벤트 발행자의 S 키 눌림 이벤트를
        // 구독자의 UseSkill() 함수가 구독
        _publisher.OnSKeyDown += _subscriber.UseSkill;



        // _warrior의 체력 변경 이벤트를
        // _hpBar의 UpdateHpBar() 함수가 구독
        _warrior.OnHpChanged += _hpBar.UpdateHpBar;
    }
}
