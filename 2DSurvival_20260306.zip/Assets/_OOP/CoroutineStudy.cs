using System.Collections;
using UnityEngine;

/*
객체 지향과 직접적인 연관 X
유니티에서 시간 흐름 제어가 필요한 경우 유용한 도구

코루틴(Coroutine)
(면접용 답변 X)
유니티에서 시간의 흐름을 제어할 수 있는 특별한 함수 같은 거
-> 일반 함수와 다르게 함수 실행을 일시 중지하고
다시 이어서 실행할 수 있는 기능

원리가 바로 이해되지 않아도 괜찮다.
사용법을 알면 된다.

지금은 내가 마음대로 사용할 수 있는 Update() 같은 걸로 생각해도 된다.
*/

public class CoroutineStudy : MonoBehaviour
{
    // 현재 실행 중인 코루틴을 저장하기 위한 변수
    Coroutine _printRoutine;


    private void Update()
    {
        // 스페이스 바를 누르면 코루틴 시작
        if(Input.GetKeyDown(KeyCode.Space) == true)
        {
            // 이미 실행 중인 코루틴이 있으면
            if(_printRoutine != null)
            {
                // 코루틴 중단
                StopCoroutine(_printRoutine);
                _printRoutine = null;
            }

            // 코루틴 실행 후 해당 코루틴 객체를 변수에 저장
            _printRoutine = StartCoroutine(PrintMessagesRoutine());
        }
    }


    IEnumerator PrintMessagesRoutine()
    {
        Debug.Log("첫 번째 메시지");

        // 1초 대기 -> 이후 다음 줄 실행
        yield return new WaitForSeconds(1);

        Debug.Log("1초 후 메시지");

        // 2.5초 대기
        yield return new WaitForSeconds(2.5f);

        Debug.Log("2.5초 더 후 메시지");

        // 실제 시간 1초 대기
        yield return new WaitForSecondsRealtime(1f);

        Debug.Log("실제 시간 1초 후 메시지");

        // 한 프레임 대기
        yield return null;

        Debug.Log("한 프레임 대기 후 메시지");

        // 다음 FixedUpdate 주기까지 대기
        yield return new WaitForFixedUpdate();

        Debug.Log("다음 FixedUpdate 대기 후 메시지");

        // 코루틴 종료
        yield break;

        Debug.Log("break 이후 코드");
    }
}
