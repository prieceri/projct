using UnityEngine;
using UnityEngine.Events;

/*
유저가 A키를 누르면
->
현재 체력 10 감소
->
체력 변경 이벤트 알림(현재 체력과 최대 체력을 매개변수로 전달)

유저가 S키를 누르면
->
현재 체력 5 증가
->
체력 변경 이벤트 알림(현재 체력과 최대 체력을 매개변수로 전달)
*/

public class Warrior : MonoBehaviour
{
    [Header("----- 체력 -----")]
    [SerializeField] float _maxHp;
    [SerializeField] float _currentHp;

    // event 키워드: 외부에서 구독/구독 해제만 가능하게 키워드
    /// <summary>
    /// 체력 변경 이벤트(현재 체력, 최대 체력)
    /// </summary>
    public event UnityAction<float, float> OnHpChanged;


    private void Update()
    {
        if(Input.GetKeyDown(KeyCode.A) == true)
        {
            AddHp(-10);
        }

        if(Input.GetKeyDown(KeyCode.S) == true)
        {
            AddHp(5);
        }
    }

    public void AddHp(float amount)
    {
        // 현재 체력 변경 후 0 ~ _maxHp 범위로 제한
        _currentHp = Mathf.Clamp(_currentHp + amount, 0, _maxHp);

        // 체력 변경 이벤트 발행
        OnHpChanged?.Invoke(_currentHp, _maxHp);
    }
}
