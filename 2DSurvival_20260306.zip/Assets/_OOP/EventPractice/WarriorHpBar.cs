using UnityEngine;
using UnityEngine.UI;

/*
Warrior 객체의 체력이 변경되었을 때 체력 바 갱신
*/

public class WarriorHpBar : MonoBehaviour
{
    [Header("----- 컴포넌트 -----")]
    [SerializeField] Image _hpBar;  // 체력바 이미지 컴포넌트


    public void UpdateHpBar(float currentHp, float maxHp)
    {
        _hpBar.fillAmount = currentHp / maxHp;
    }
}
