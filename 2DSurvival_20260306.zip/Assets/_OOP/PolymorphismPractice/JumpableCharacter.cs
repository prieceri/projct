using UnityEngine;

namespace OOPStudy
{
    /*
    Character의 기본 좌우 이동 기능에 Rigidbody2D를 사용하여 점프 기능이 추가된 캐릭터 역할
    (Update()에도 virtual, override 적용 가능)
    Character의 기본 좌우 이동 기능을 Rigidbody2D를 사용하는 방식으로 덮어쓰기
    */

    [RequireComponent(typeof(Rigidbody2D))]
    public class JumpableCharacter : Character
    {
        Rigidbody2D _rigid;
        [SerializeField] float _jumpPower;

        private void Awake()
        {
            _rigid = GetComponent<Rigidbody2D>();
        }

        protected override void Update()
        {
            HandleMove();
            HandleJump();
        }

        protected override void HandleMove()
        {
            MoveHorizontal();
        }

        protected override void MoveHorizontal()
        {
            float x = Input.GetAxis("Horizontal");
            _rigid.linearVelocityX = x * _speed;
        }

        void HandleJump()
        {
            if(Input.GetButtonDown("Jump") == true)
            {
                _rigid.AddForce(Vector2.up * _jumpPower, ForceMode2D.Impulse);
            }
        }
    }
}


