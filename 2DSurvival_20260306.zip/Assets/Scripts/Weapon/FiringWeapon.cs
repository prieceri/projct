using System.Collections;
using UnityEngine;

// 대미지(Weapon)
// 공격 쿨타임
// 총알 속력
// 총알 지속 시간

// 한 번에(연발로) 발사하는 총알 수
// 연발 사이 간격 시간

/// <summary>
/// 일정 시간마다 총알을 발사하는 무기
/// </summary>
public abstract class FiringWeapon : Weapon
{
    [Header("----- 컴포넌트 -----")]
    [SerializeField] TargetSensor _targetSensor;    // 대상 감지기

    [Header("----- 런타임 데이터 -----")]
    [SerializeField] protected float _cooltime;       // 공격 쿨타임
    [SerializeField] protected float _bulletSpeed;    // 총알 속력
    [SerializeField] protected float _bulletDuration; // 총알 지속 시간
    [SerializeField] protected int _bulletCount;      // 연발 시 총알 개수
    [SerializeField] protected float _fireDelay;      // 연발 시 총알 사이 간격 시간
    [SerializeField] protected float _shootingRange;      // 발사 사정거리

    Coroutine _attackRoutine;       // 공격 코루틴 변수

    public override void Initialize()
    {
        CalculateStats();
        _attackRoutine = StartCoroutine(AttackRoutine());
    }

    protected override void CalculateStats()
    {
        WeaponStatData statData = _data.GetStatData(_level);
        _damage = statData.GetStat(WeaponStatType.Damage);
        _bulletSpeed = statData.GetStat(WeaponStatType.BulletSpeed);
        _bulletCount = Mathf.RoundToInt(statData.GetStat(WeaponStatType.BulletCount));
        _cooltime = statData.GetStat(WeaponStatType.Cooltime);
        _fireDelay = statData.GetStat(WeaponStatType.FireDelay);
        _bulletDuration = statData.GetStat(WeaponStatType.BulletDuration);
        _shootingRange = statData.GetStat(WeaponStatType.ShootingRange);
    }



    /// <summary>
    /// 일정 주기로 발사 루틴을 실행하는 코루틴
    /// </summary>
    /// <returns></returns>
    IEnumerator AttackRoutine()
    {
        while (true)
        {
            yield return new WaitForSeconds(_cooltime);
            StartCoroutine(FireRoutine());
        }
    }

    /// <summary>
    /// 설정된 수만큼 연발로 총알을 발사하는 코루틴
    /// </summary>
    /// <returns></returns>
    IEnumerator FireRoutine()
    {
        for(int i = 0; i < _bulletCount; i++)
        {
            SpawnBullet();
            yield return new WaitForSeconds(_fireDelay);
        }
    }

    protected abstract void SpawnBullet();


    /// <summary>
    /// 가장 가까운 타겟 방향을 반환하는 함수
    /// </summary>
    /// <returns></returns>
    protected Vector3 GetNearestTagetDirection()
    {
        // 사정거리 이내 가장 가까운 타겟 트랜스폼 가져오기
        Transform target = _targetSensor.GetNearestTaget(_shootingRange);

        if (target == null)
            return Random.insideUnitCircle.normalized;
        else
        {
            Vector3 dir = (target.position - transform.position).normalized;
            return dir;
        }
    }

    protected Vector3 GetRandomDirection()
    {
        return Random.insideUnitCircle.normalized;
    }
}
