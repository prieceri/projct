using UnityEngine;

/// <summary>
/// 일정 주기로 회전하는 낫 형태의 총알을 발사하는 무기
/// </summary>
public class ScytheWeapon : FiringWeapon
{
    [Header("----- 런타임 데이터 -----")]
    [SerializeField] float _damageDelay;        // 대미지 입히는 시간 간격
    [SerializeField] float _bulletRange;        // 총알 범위
    [SerializeField] float _rotSpeed;           // 회전 속력

    [Header("----- 총알 프리팹 -----")]
    [SerializeField] ScytheBullet _bulletPrefab;

    protected override void CalculateStats()
    {
        base.CalculateStats();

        WeaponStatData statData = _data.GetStatData(_level);
        _rotSpeed = statData.GetStat(WeaponStatType.RotSpeed);
        _damageDelay = statData.GetStat(WeaponStatType.DamageDelay);
        _bulletRange = statData.GetStat(WeaponStatType.BulletRange);
    }

    protected override void SpawnBullet()
    {
        ScytheBullet bullet = Instantiate(_bulletPrefab);
        bullet.transform.position = transform.position;

        bullet.SetDamage(_damage);
        bullet.SetDamageDelay(_damageDelay);
        bullet.SetDuration(_bulletDuration);
        bullet.SetMaxScale(_bulletRange);
        bullet.SetRotSpeed(_rotSpeed);
        bullet.SetSpeed(_bulletSpeed);

        bullet.SetDirection(GetRandomDirection());
    }
}
