using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 총알을 배치하고 스스로 회전하여 배치된 총알들로 적을 공격하는 무기
/// </summary>
public class RotatingWeapon : Weapon
{
    [Header("----- 리소스 -----")]
    [SerializeField] Bullet _bulletPrefab;  // 총알 프리팹

    [Header("----- 런타임 데이터 -----")]
    [SerializeField] float _shootingRange;      // 사정거리(총알 회전 궤적 반지름)
    [SerializeField] float _rotSpeed;           // 회전 속력
    [SerializeField] int _bulletCount;          // 총알 수

    List<Bullet> _bullets = new List<Bullet>(); // 생성된 총알 리스트

    Coroutine _rotateRoutine;   // 회전 코루틴 변수

    public override void Initialize()
    {
        CalculateStats();
        _rotateRoutine = StartCoroutine(RotateRoutine());
    }

    protected override void CalculateStats()
    {
        WeaponStatData statData = _data.GetStatData(_level);
        _damage = statData.GetStat(WeaponStatType.Damage);
        _rotSpeed = statData.GetStat(WeaponStatType.RotSpeed);
        _shootingRange = statData.GetStat(WeaponStatType.ShootingRange);
        //_bulletCount = (int)statData.GetStat(WeaponStatType.BulletCount);
        // float를 int로 명시적 형변환을 하면 내림
        // Round - 반올림, Floor - 내림, Ceil - 올림
        _bulletCount = Mathf.RoundToInt(statData.GetStat(WeaponStatType.BulletCount));

        // 총알 생성
        SpawnBullets();
    }


    //private void Update()
    //{
    //    HandleRotation();
    //}

    IEnumerator RotateRoutine()
    {
        while (true)
        {
            HandleRotation();
            yield return null;
        }
    }

    void HandleRotation()
    {
        transform.Rotate(0, 0, _rotSpeed * Time.deltaTime);

        // 오일러각을 직접 수정하는 방식
        //Vector3 euler = transform.eulerAngles;
        //euler.z += _rotSpeed * Time.deltaTime;
        //transform.eulerAngles = euler;
    }

    void SpawnBullets()
    {
        // 기존 총알들 제거
        RemoveBullets();

        // 자신 게임오브젝트 회전값 초기화
        transform.rotation = Quaternion.identity;

        // 총알 사이 각도
        float angle = 360 / _bulletCount;
        for(int i = 0; i < _bulletCount; i++)
        {
            Bullet bullet = Instantiate(_bulletPrefab, transform);

            // 원 위의 점 위치는 x축으로부터의 각도에 따라 구할 수 있다.
            // x: cos(각도)
            // y: sin(각도)

            Vector3 dir = new Vector3(
                Mathf.Cos(i * angle * Mathf.Deg2Rad),
                Mathf.Sin(i * angle * Mathf.Deg2Rad),
                0);
            bullet.transform.up = dir;
            bullet.transform.localPosition = dir * _shootingRange;

            // 총알 대미지 설정
            bullet.SetDamage(_damage);

            _bullets.Add(bullet);

        }
    }

    /// <summary>
    /// 기존에 생성된 총알들을 제거하는 함수
    /// </summary>
    void RemoveBullets()
    {
        foreach(Bullet bullet in _bullets)
        {
            // 총알 게임오브젝트 파괴
            Destroy(bullet.gameObject);
        }
        // 생성된 총알 리스트 비우기
        _bullets.Clear();
    }
}
