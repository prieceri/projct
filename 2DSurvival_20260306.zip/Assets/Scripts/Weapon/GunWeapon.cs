using UnityEngine;

/// <summary>
/// 일정 시간마다 가까운 적 캐릭터를 향해 GunBullet을 발사하는 무기
/// </summary>
public class GunWeapon : FiringWeapon
{
    [Header("----- 런타임 데이터 -----")]
    [SerializeField] int _attackCount;      // 총알 공격 횟수

    [Header("----- 총알 프리팹 -----")]
    [SerializeField] GunBullet _bulletPrefab;

    protected override void CalculateStats()
    {
        base.CalculateStats();

        // _attackCount 스탯 계산
        _attackCount = Mathf.RoundToInt(_data.GetStatData(_level).GetStat(WeaponStatType.AttackCount));
    }

    protected override void SpawnBullet()
    {
        // 투사체 총알 프리팹 복제 생성
        GunBullet bullet = Instantiate(_bulletPrefab);

        // 총알 생성 위치 설정
        bullet.transform.position = transform.position;

        // 투사체 총알 스탯 설정
        bullet.SetDamage(_damage);
        bullet.SetSpeed(_bulletSpeed);
        bullet.SetDuration(_bulletDuration);
        bullet.SetCount(_attackCount);
        bullet.SetDirection(GetNearestTagetDirection());
    }
}
