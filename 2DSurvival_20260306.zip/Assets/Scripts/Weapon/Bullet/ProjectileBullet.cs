using UnityEngine;

/// <summary>
/// 처음에 정해진 방향을 향해 일정한 속력으로 날아가 적 캐릭터에 닿으면
/// 대미지를 입히고 파괴되는 총알
/// </summary>
public class ProjectileBullet : Bullet
{
    [Header("----- 런타임 데이터 -----")]
    [SerializeField] protected float _speed;      // 속력
    [SerializeField] protected float _duration;   // 지속 시간(적을 빗겨 가면 씬에 무한히 남아 있게 되는 일을 방지)
    [SerializeField] protected Vector3 _dir;      // 이동 방향

    protected float _timer;     // 타이머


    public void SetSpeed(float speed)
    {
        _speed = speed;
    }
    public void SetDuration(float duration)
    {
        _duration = duration;
    }
    /// <summary>
    /// 총알의 이동 방향을 설정하는 함수
    /// </summary>
    /// <param name="dir"></param>
    public void SetDirection(Vector3 dir)
    {
        // 이동 방향 설정
        _dir = dir.normalized;

        // 이동 방향에 맞게 회전
        transform.up = _dir;
    }

    protected virtual void FixedUpdate()
    {
        transform.Translate(_dir * _speed * Time.fixedDeltaTime, Space.World);

        _timer += Time.fixedDeltaTime;
        if(_timer > _duration)
        {
            Destroy(gameObject);
        }
    }


    //public override void Attack(Enemy enemy)
    //{
    //    // 적 공격
    //    base.Attack(enemy);

    //    // 자신 게임오브젝트 파괴
    //    Destroy(gameObject);
    //}
}
