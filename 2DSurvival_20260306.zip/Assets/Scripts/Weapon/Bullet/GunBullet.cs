using UnityEngine;

/// <summary>
/// Gun 무기의 총알
/// 적 캐릭터를 공격할 때마다 Count가 감소하고 Count가 0이 되면 파괴된다.
/// </summary>
public class GunBullet : ProjectileBullet
{
    [SerializeField] int _count;        // 공격 횟수

    public void SetCount(int count)
    {
        _count = count;
    }

    public override void Attack(Enemy enemy)
    {
        base.Attack(enemy);
        _count--;
        if(_count <= 0)
        {
            Destroy(gameObject);
        }
    }
}
