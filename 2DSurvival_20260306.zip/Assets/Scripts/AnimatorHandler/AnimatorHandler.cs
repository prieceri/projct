using UnityEngine;

/// <summary>
/// 캐릭터 애니메이터를 다루는 역할
/// </summary>
public class AnimatorHandler : MonoBehaviour
{
    [Header("----- 컴포넌트 -----")]
    [SerializeField] SpriteRenderer _renderer;
    [SerializeField] Animator _animator;

    /// <summary>
    /// 캐릭터가 이동했을 때를 다루는 함수
    /// </summary>
    /// <param name="velocity"></param>
    public void HandleMoved(Vector3 velocity)
    {
        // 스프라이트 렌더러 플립
        if (velocity.x > 0)
        {
            _renderer.flipX = false;
        }
        if (velocity.x < 0)
        {
            _renderer.flipX = true;
        }

        // 애니메이터 패러미터
        _animator.SetFloat("MoveSpeed", velocity.magnitude);
    }

    /// <summary>
    /// 캐릭터가 사망했을 때를 다루는 함수
    /// </summary>
    public void HandleDead()
    {
        _renderer.sortingOrder = -1;

        _animator.SetTrigger("OnDead");
    }

    public void HandleHit()
    {
        _animator.SetTrigger("OnHit");
    }
}
