using UnityEngine;
using UnityEngine.Events;

/// <summary>
/// 주인공 캐릭터 런타임 데이터 모델
/// </summary>
public class HeroModel : CharacterModel
{
    [Header("----- 경험치 -----")]
    [SerializeField] float _currentExp;     // 현재 경험치
    [SerializeField] float _maxExp;         // 최대 경험치
    [SerializeField] int _level;            // 레벨

    /// <summary>
    /// 경험치 변경 이벤트(현재 경험치, 최대 경험치)
    /// </summary>
    public event UnityAction<float, float> OnExpChanged;

    /// <summary>
    /// 레벨 변경 이벤트(현재 레벨)
    /// </summary>
    public event UnityAction<int> OnLevelChanged;

    /// <summary>
    /// 경험치를 획득하는 함수
    /// </summary>
    /// <param name="amount"></param>
    public void AddExp(float amount)
    {
        // 경험치 증가
        _currentExp += amount;

        // 경험치 변경 이벤트 발행
        OnExpChanged?.Invoke(_currentExp, _maxExp);
        

        // 경험치가 다 찼으면
        if(_currentExp >= _maxExp)
        {
            _currentExp -= _maxExp;

            // 레벨업
            _level++;

            // 레벨 변경 이벤트 발행
            OnLevelChanged?.Invoke(_level);
        }
    }
}
