using UnityEngine;

/// <summary>
/// 플레이어 캐릭터 담당(이동, HUD, 무기 홀더, 스탯 등등)
/// </summary>
public class Hero : MonoBehaviour
{
    [Header("----- 컴포넌트 -----")]
    [SerializeField] HeroModel _model;
    [SerializeField] Mover _mover;
    [SerializeField] AnimatorHandler _animatorHandler;
    [SerializeField] CharacterView _view;
    [SerializeField] expView _expBarView;
    [SerializeField] Upgrader _upgrade;

    private void Awake()
    {
        // 이동 이벤트 구독
        _mover.OnMoved += _animatorHandler.HandleMoved;

        // 체력 변경 이벤트 구독
        _model.OnHpChanged += _view.UpdateHp;

        _model.OnExpChanged += _expBarView.UpdateExp;

        _model.OnLevelChanged += UpgradeOpen;
    }

    public void Initialize()
    {
        _model.Initialize();
    }


    /// <summary>
    /// 업그래이드 뷰 오픈
    /// </summary>
    public void UpgradeOpen(int Level)
    {
        _upgrade.BeginSelection();
    }

    /// <summary>
    /// 유저 입력에 따라 이동하는 함수
    /// </summary>
    /// <param name="dir">이동 방향</param>
    public void Move(Vector3 dir)
    {
        _mover.Move(dir);
    }

    /// <summary>
    /// 피격 함수
    /// </summary>
    /// <param name="damage"></param>
    public void TakeHit(float damage)
    {
        _model.TakeDamage(damage);
    }

    /// <summary>
    /// 경험치 획득 함수
    /// </summary>
    /// <param name="amount"></param>
    public void AddExp(float amount)
    {
        _model.AddExp(amount);
    }
}
