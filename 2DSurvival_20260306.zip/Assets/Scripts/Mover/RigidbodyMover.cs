using UnityEngine;
using UnityEngine.Events;

/// <summary>
/// 게임오브젝트의 Rigidbody2D를 조절해 원하는 방향으로 일정 속력으로 이동하는 역할
/// </summary>
[RequireComponent(typeof(Rigidbody2D))]
public class RigidbodyMover : Mover
{
    Rigidbody2D _rigid;

    public override event UnityAction<Vector3> OnMoved;

    private void Awake()
    {
        _rigid = GetComponent<Rigidbody2D>();
    }

    public override void Move(Vector3 dir)
    {
        _rigid.linearVelocity = dir * _speed;
        OnMoved?.Invoke(_rigid.linearVelocity);
    }
}
