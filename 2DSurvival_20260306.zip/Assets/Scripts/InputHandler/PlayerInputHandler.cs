using UnityEngine;
using UnityEngine.Events;
using UnityEngine.InputSystem;

/// <summary>
/// 유니티의 InputSystem의 PlayerInput을 활용해 입력을 알리는 역할
/// </summary>
public class PlayerInputHandler : InputHandler
{
    public override event UnityAction<Vector2> OnMoveInput;

    Vector2 _inputVector;

    private void Update()
    {
        OnMoveInput?.Invoke(_inputVector);
    }

    // InputSystem의 SendMessages 방식
    public void OnMove(InputValue inputValue)
    {
        _inputVector = inputValue.Get<Vector2>();
    }
}
