using UnityEngine;

public class Upgrader : MonoBehaviour
{
    [Header("----- 컴포넌트 -----")]
    [SerializeField] Weapon[] _weapons;             // 무기 배열
    [SerializeField] UpgradeView[] _upgradeViews;   // 업그레이드 뷰 배열
    [SerializeField] GameObject _upgradePanel;      // 업그레이드 패널


    // 테스트용
    private void Update()
    {
        if(Input.GetKeyDown(KeyCode.Alpha1) == true)
        {
            BeginSelection();
        }

        if(Input.GetKeyDown(KeyCode.Alpha2) == true)
        {
            EndSelection();
        }

        //if(Input.GetKeyDown(KeyCode.Alpha3) == true)
        //{
        //    _weapons[2].Upgrade();
        //}


    }


    /// <summary>
    /// 업그레이드 선택을 시작하는 함수
    /// </summary>
    public void BeginSelection()
    {
        for (int i = 0; i < _upgradeViews.Length; i++)
        {
            if(i < _upgradeViews.Length)
            {
                _upgradeViews[i].Initialize(_weapons[i]);
                _upgradeViews[i].gameObject.SetActive(true);
            }
            else
            {
                _upgradeViews[i].gameObject.SetActive(false);
            }
        }

        _upgradePanel.gameObject.SetActive(true);
        Time.timeScale = 0;
    }

    /// <summary>
    /// 업그레이드 선택을 종료하는 함수
    /// </summary>
    public void EndSelection()
    {
        _upgradePanel.gameObject.SetActive(false);
        Time.timeScale = 1.0f;
    }

}
