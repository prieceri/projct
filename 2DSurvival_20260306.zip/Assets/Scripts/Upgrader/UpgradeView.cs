﻿using TMPro;
using UnityEngine;
using UnityEngine.UI;


/// <summary>
/// 하나의 업그레이드 Ui 요소를 담당하는 뷰
/// </summary>
public class UpgradeView : MonoBehaviour
{
    [Header("----- 컴포넌트 ------")]
    [SerializeField] Image _icon;           // 무기 아이콘
    [SerializeField] TMP_Text _nameText;    // 무기 이름 텍스트 
    [SerializeField] TMP_Text _descText;    // 무기 설명 텍스트 
    [SerializeField] TMP_Text _levelText;   // 레벨 텍스트

    // 업그레이드 대상 객체
    Iupgradable _upgradable;

    
    /// <summary>
    /// 초기화 함수
    /// 업그레이드 정보를 Ui 표시하고 클릭 이벤트 발생
    /// </summary>
    /// <param name="upgradable"></param>
    public void Initialize(Iupgradable upgradable)
    {
        _upgradable = upgradable;   

        _icon.sprite = _upgradable.IconSprite;
        _nameText.text = _upgradable.UpgradeName;
        _descText.text = _upgradable.Desc;
        _levelText.text = $"- Level {_upgradable.Level + 2} -";
        
    }


    /// <summary>
    /// 클릭되었을 때를 다루는 함수
    /// </summary>
    public void HandleClicked()
    {
        if (_upgradable != null)
        {
            _upgradable.Upgrad();

            //To Do 
            //업그레이드 선택 끝났음 알림
        }

    }

}
