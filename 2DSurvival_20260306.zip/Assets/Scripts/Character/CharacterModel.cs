using UnityEngine;
using UnityEngine.Events;

public class CharacterModel : MonoBehaviour
{
    [Header("----- 런타임 데이터 -----")]
    [SerializeField] protected float _maxHp;          // 최대 체력
    [SerializeField] protected float _currentHp;      // 현재 체력

    /// <summary>
    /// 체력 변경 이벤트(현재 체력, 최대 체력)
    /// </summary>
    public event UnityAction<float, float> OnHpChanged;

    /// <summary>
    /// 사망 이벤트
    /// </summary>
    public event UnityAction OnDead;

    /// <summary>
    /// 생존 여부
    /// </summary>
    public bool IsAlive => _currentHp > 0;
    public void Initialize()
    {
        _currentHp = _maxHp;
    }

    /// <summary>
    /// 대미지를 입는 함수
    /// </summary>
    /// <param name="amount"></param>
    public void TakeDamage(float amount)
    {
        if (IsAlive == false) return;

        _currentHp = Mathf.Min(_currentHp - amount, _maxHp);

        // 체력 변경 이벤트 발행
        OnHpChanged?.Invoke(_currentHp, _maxHp);

        if (IsAlive == false)
        {
            // 사망 이벤트 발행
            OnDead?.Invoke();
        }
    }
}
