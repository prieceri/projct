using UnityEngine;


/// <summary>
/// 적 캐릭터를 담당하는 역할
/// </summary>
public class Enemy : MonoBehaviour
{
    Hero _hero;             // 플레이어 캐릭터
    EnemySpawner _spawner;  // 적 생성기

    [Header("----- 컴포넌트 -----")]
    [SerializeField] EnemyModel _model;                 // 데이터 모델
    [SerializeField] Mover _mover;                      // 이동자
    [SerializeField] AnimatorHandler _animatorHandler;  // 애니메이터 핸들러
    [SerializeField] CharacterView _view;                   // UI(HUD)
    [SerializeField] Collider2D _collider;              // 콜라이더
    [SerializeField] Rigidbody2D _rigid;                // 리지드바디

    [Header("----- 런타임 데이터 -----")]
    [SerializeField] float _maxDist;        // 타겟으로부터 최대 거리

    IEnemyState _state;                         // 현재 상태 객체(를 가리키는 인터페이스 변수)
    IEnemyState[] _states;                      // 상태 객체 배열


    private void Awake()
    {
        // 이동 이벤트 구독
        _mover.OnMoved += _animatorHandler.HandleMoved;

        // 체력 변경 이벤트 구독
        _model.OnHpChanged += _view.UpdateHp;

        // 사망 이벤트 구독
        _model.OnDead += Die;
    }

    public void Initialize(Hero hero, EnemySpawner spawner)
    {
        _hero = hero;
        _spawner = spawner;

        // 상태 객체들 생성
        _states = new IEnemyState[]
        {
            new NormalState(this),
            new StaggerState(this, 0.3f),
            new DeadState(this, 1.0f)
        };

        // 현재 상태를 Normal 상태로 설정
        _state = _states[(int)EnemyStateType.Normal];
    }

    /// <summary>
    /// 상태 변경 함수
    /// 기존 상태와 새 상태가 동일한 경우에는 실행하지 않는다.
    /// 기존 상태가 사망 상태일 경우에는 실행하지 않는다.
    /// </summary>
    /// <param name="stateType">새 상태 종류</param>
    public void ChangeState(EnemyStateType stateType)
    {
        if(_state != null)
        {
            // 기존 상태가 사망 상태인 경우
            if (_state.StateType == EnemyStateType.Dead) return;

            // 기존 상태와 새 상태가 같은 경우
            if (_state.StateType == stateType) return;

            // 기존 상태 종료 실행
            _state.Exit();
        }

        // 현재 상태를 새 상태로 변경
        _state = _states[(int)stateType];

        // 현재 상태 시작 실행
        _state.Enter();
    }


    private void Update()
    {
        if (_state == null) return;

        // 현재 상태의 업데이트 함수 호출
        _state.Update();
    }

    /// <summary>
    /// 목표 방향으로 추적하는 함수
    /// </summary>
    public void Follow()
    {
        // 재배치 체크
        // 플레이어 캐릭터와의 거리 구하기
        float dist = Vector3.Distance(_hero.transform.position, transform.position);
        if(dist > _maxDist)
        {
            transform.position = _spawner.GetSpawnPosition();
        }

        // 목표 방향 구하기
        Vector3 dir = (_hero.transform.position - transform.position).normalized;

        // 목표 방향으로 이동
        _mover.Move(dir);
    }

    /// <summary>
    /// 이동 정지 함수
    /// </summary>
    public void Stop()
    {
        _mover.Move(Vector3.zero);
    }

    /// <summary>
    /// 피격 함수
    /// </summary>
    /// <param name="damage">대미지</param>
    public void TakeHit(float damage)
    {
        // 1) 로직 처리
        _model.TakeDamage(damage);

        if (_model.IsAlive == false) return;

        // 2) 피격 애니메이션 재생
        _animatorHandler.HandleHit();

        // 3) 상태 변경(Stagger)
        ChangeState(EnemyStateType.Stagger);
    }

    /// <summary>
    /// 타겟을 공격하는 함수
    /// </summary>
    public void AttackTarget()
    {
        _hero.TakeHit(_model.Damage);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.tag == "Player")
        {
            AttackTarget();
        }
    }


    /// <summary>
    /// 사망 함수
    /// </summary>
    public void Die()
    {
        // 1) 사망 애니메이션 재생(애니메이터 트리거)
        _animatorHandler.HandleDead();

        // 2) 콜라이더 끄기
        _collider.enabled = false;

        // 3) 리지드바디 끄기
        _rigid.simulated = false;

        // 4) 상태 변경(Dead)
        ChangeState(EnemyStateType.Dead);

        // 5) 플레이어 캐릭터(주인공) 경험치 획득
        _hero.AddExp(_model.ExpReward);
    }

    /// <summary>
    /// 게임에서 제거하는 함수
    /// </summary>
    public void Remove()
    {
        Destroy(gameObject);
    }
}




//public class Enemy : MonoBehaviour
//{
//    Hero _hero;             // 플레이어 캐릭터
//    EnemySpawner _spawner;  // 적 생성기

//    [Header("----- 컴포넌트 -----")]
//    [SerializeField] EnemyModel _model;                 // 데이터 모델
//    [SerializeField] Mover _mover;                      // 이동자
//    [SerializeField] AnimatorHandler _animatorHandler;  // 애니메이터 핸들러
//    [SerializeField] CharacterView _view;                   // UI(HUD)
//    [SerializeField] Collider2D _collider;              // 콜라이더
//    [SerializeField] Rigidbody2D _rigid;                // 리지드바디

//    [Header("----- 런타임 데이터 -----")]
//    [SerializeField] float _maxDist;        // 타겟으로부터 최대 거리
//    [SerializeField] EnemyStateType _currentState;  // 현재 상태

//    float _timer;       // 타이머


//    private void Awake()
//    {
//        // 이동 이벤트 구독
//        _mover.OnMoved += _animatorHandler.HandleMoved;

//        // 체력 변경 이벤트 구독
//        _model.OnHpChanged += _view.UpdateHp;

//        // 사망 이벤트 구독
//        _model.OnDead += Die;
//    }

//    public void Initialize(Hero hero, EnemySpawner spawner)
//    {
//        _hero = hero;
//        _spawner = spawner;
//    }


//    private void Update()
//    {
//        switch (_currentState)
//        {
//            case EnemyStateType.Normal:
//                Follow();
//                break;
//            case EnemyStateType.Stagger:
//                _timer -= Time.deltaTime;
//                if (_timer < 0)
//                {
//                    _currentState = EnemyStateType.Normal;
//                }
//                break;
//            case EnemyStateType.Dead:
//                break;
//        }
//    }

//    /// <summary>
//    /// 목표 방향으로 추적하는 함수
//    /// </summary>
//    public void Follow()
//    {
//        // 재배치 체크
//        // 플레이어 캐릭터와의 거리 구하기
//        float dist = Vector3.Distance(_hero.transform.position, transform.position);
//        if (dist > _maxDist)
//        {
//            transform.position = _spawner.GetSpawnPosition();
//        }

//        // 목표 방향 구하기
//        Vector3 dir = (_hero.transform.position - transform.position).normalized;

//        // 목표 방향으로 이동
//        _mover.Move(dir);
//    }

//    /// <summary>
//    /// 이동 정지 함수
//    /// </summary>
//    public void Stop()
//    {
//        _mover.Move(Vector3.zero);
//    }

//    /// <summary>
//    /// 피격 함수
//    /// </summary>
//    /// <param name="damage">대미지</param>
//    public void TakeHit(float damage)
//    {
//        // 1) 로직 처리
//        _model.TakeDamage(damage);

//        if (_model.IsAlive == false) return;

//        // 2) 이동 정지
//        Stop();

//        // 3) 피격 애니메이션 재생
//        _animatorHandler.HandleHit();

//        // 4) 상태 변화
//        _currentState = EnemyStateType.Stagger;

//        // 5) 일정 시간 후 자동으로 일반 상태 전환
//        _timer = 0.3f;
//    }

//    /// <summary>
//    /// 타겟을 공격하는 함수
//    /// </summary>
//    public void AttackTarget()
//    {
//        _hero.TakeHit(_model.Damage);
//    }

//    private void OnCollisionEnter2D(Collision2D collision)
//    {
//        if (collision.gameObject.tag == "Player")
//        {
//            AttackTarget();
//        }
//    }


//    /// <summary>
//    /// 사망 함수
//    /// </summary>
//    public void Die()
//    {
//        // 1) 사망 애니메이션 재생(애니메이터 트리거)
//        _animatorHandler.HandleDead();

//        // 2) 상태 변경
//        _currentState = EnemyStateType.Dead;

//        // 3) 콜라이더 끄기
//        _collider.enabled = false;

//        // 4) 리지드바디 끄기
//        _rigid.simulated = false;

//        // 5) 1초 뒤 게임오브젝트 파괴 
//        Invoke("Remove", 1.0f);     // Invoke(): 남용하면 안 되는 방식
//    }

//    /// <summary>
//    /// 게임에서 제거하는 함수
//    /// </summary>
//    public void Remove()
//    {
//        Destroy(gameObject);
//    }
//}