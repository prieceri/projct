using UnityEngine;
using UnityEngine.UI;

public class ExpBarView : MonoBehaviour
{
    [SerializeField] Image _expbar;

    public void UpdateExp(float currentExp, float maxExp)
    {
        _expbar.fillAmount = currentExp / maxExp;
    }
}
