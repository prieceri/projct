using UnityEngine;

public class Upgrader : MonoBehaviour
{
    [Header("----- 컴포넌트 -----")]
    [SerializeField] Weapon[] _weapons;

    // 테스트용
    private void Update()
    {
        if(Input.GetKeyDown(KeyCode.Alpha1) == true)
        {
            _weapons[0].Upgrade();
        }

        if(Input.GetKeyDown(KeyCode.Alpha2) == true)
        {
            _weapons[1].Upgrade();
        }

        if(Input.GetKeyDown(KeyCode.Alpha3) == true)
        {
            _weapons[2].Upgrade();
        }
    }
}
