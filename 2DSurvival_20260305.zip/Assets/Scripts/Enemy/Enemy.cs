using UnityEngine;


/// <summary>
/// 적 캐릭터를 담당하는 역할
/// </summary>
public class Enemy : MonoBehaviour
{
    Hero _hero;             // 플레이어 캐릭터
    EnemySpawner _spawner;  // 적 생성기

    [Header("----- 컴포넌트 -----")]
    [SerializeField] EnemyModel _model;                 // 데이터 모델
    [SerializeField] Mover _mover;                      // 이동자
    [SerializeField] AnimatorHandler _animatorHandler;  // 애니메이터 핸들러
    [SerializeField] CharacterView _view;                   // UI(HUD)
    [SerializeField] Collider2D _collider;              // 콜라이더
    [SerializeField] Rigidbody2D _rigid;                // 리지드바디

    [Header("----- 런타임 데이터 -----")]
    [SerializeField] float _maxDist;        // 타겟으로부터 최대 거리

 

    IEnemyState _state;     //현재 상태 객체를 가리키는 인터페이스 변수
    IEnemyState[] _states = new IEnemyState[(int)EnemyStateType.Count]; //상태 리스트

 


    private void Awake()
    {
        // 이동 이벤트 구독
        _mover.OnMoved += _animatorHandler.HandleMoved;

        // 체력 변경 이벤트 구독
        _model.OnHpChanged += _view.UpdateHp;

        // 사망 이벤트 구독
        _model.OnDead += Die;
    }

    public void Initialize(Hero hero, EnemySpawner spawner)
    {
        _hero = hero;
        _spawner = spawner;

        _states = new IEnemyState[]
        {
            new NormalState(this),
            new StaggerState(this, 0.3f),
            new DeadState(this, 1.0f),
        };

        _state = _states[(int)EnemyStateType.Normal];
    }


    /// <summary>
    /// 상태 변환 함수
    /// 기존 상태와 새 상태가 동일한 경우에는 실행하지 않는다.
    /// ex)기존 상태가 사망 상태일 경우에는 실행하지 않는다.
    /// </summary>
    /// <param name="stateType">스텟 타입</param>
    public void ChangeState(EnemyStateType stateType)
    {
        if(_state != null)
        {
            // 기존 상태가 사망 상태인 경우
            if(_state.StateType == EnemyStateType.Dead) return;
            
            // 기존 상태와 새상태가 같은경우
            if (_state.StateType == stateType) return;

            //기존 상태 종료
            _state.Exit();

        }

        // 현재 상태를 새 상태로 변경
        _state = _states[(int)stateType];

        // 현재 상태 시작 실행
        _state.Enter();
    }


    private void Update()
    {
        if(_state ==  null) return;

        // 현재 상티의 업데이트 함수 호출
        _state.Update();
        
    }

    /// <summary>
    /// 목표 방향으로 추적하는 함수
    /// </summary>
    public void Follow()
    {
        // 재배치 체크
        // 플레이어 캐릭터와의 거리 구하기
        float dist = Vector3.Distance(_hero.transform.position, transform.position);
        if(dist > _maxDist)
        {
            transform.position = _spawner.GetSpawnPosition();
        }

        // 목표 방향 구하기
        Vector3 dir = (_hero.transform.position - transform.position).normalized;

        // 목표 방향으로 이동
        _mover.Move(dir);
    }

    /// <summary>
    /// 이동 정지 함수
    /// </summary>
    public void Stop()
    {
        _mover.Move(Vector3.zero);
    }

    /// <summary>
    /// 피격 함수
    /// </summary>
    /// <param name="damage">대미지</param>
    public void TakeHit(float damage)
    {
        // 1) 로직 처리
        _model.TakeDamage(damage);

        if (_model.IsAlive == false) return;

        // 2) 이동 정지
        Stop();

        // 3) 피격 애니메이션 재생
        _animatorHandler.HandleHit();
        

        // 4) 상태 변화(stager)
        ChangeState(EnemyStateType.Stagger);
        // ToDo
        

       
        
    }

    /// <summary>
    /// 타겟을 공격하는 함수
    /// </summary>
    public void AttackTarget()
    {
        _hero.TakeHit(_model.Damage);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.tag == "Player")
        {
            AttackTarget();
        }
    }


    /// <summary>
    /// 사망 함수
    /// </summary>
    public void Die()
    {
        // 1) 사망 애니메이션 재생(애니메이터 트리거)
        _animatorHandler.HandleDead();

        // 3) 콜라이더 끄기
        _collider.enabled = false;

        // 4) 리지드바디 끄기
        _rigid.simulated = false;

        // 상태 변환(Dead)
        ChangeState(EnemyStateType.Dead);
        
        // 플래이어 캐릭터 경험치 획득 
        _hero.AddExp(_model.ExpReward);
       
        // ToDo

    }

    /// <summary>
    /// 게임에서 제거하는 함수
    /// </summary>
    public void Remove()
    {
        Destroy(gameObject);
    }
}



//public class enemy : monobehaviour
//{
//    hero _hero;             // 플레이어 캐릭터
//    enemyspawner _spawner;  // 적 생성기

//    [header("----- 컴포넌트 -----")]
//    [serializefield] enemymodel _model;                 // 데이터 모델
//    [serializefield] mover _mover;                      // 이동자
//    [serializefield] animatorhandler _animatorhandler;  // 애니메이터 핸들러
//    [serializefield] characterview _view;                   // ui(hud)
//    [serializefield] collider2d _collider;              // 콜라이더
//    [serializefield] rigidbody2d _rigid;                // 리지드바디

//    [header("----- 런타임 데이터 -----")]
//    [serializefield] float _maxdist;        // 타겟으로부터 최대 거리
//    [serializefield] enemystatetype _currentstate;  // 현재 상태

//    float _timer;       // 타이머


//    private void awake()
//    {
//        // 이동 이벤트 구독
//        _mover.onmoved += _animatorhandler.handlemoved;

//        // 체력 변경 이벤트 구독
//        _model.onhpchanged += _view.updatehp;

//        // 사망 이벤트 구독
//        _model.ondead += die;
//    }

//    public void initialize(hero hero, enemyspawner spawner)
//    {
//        _hero = hero;
//        _spawner = spawner;
//    }


//    private void update()
//    {
//        switch (_currentstate)
//        {
//            case enemystatetype.normal:
//                follow();
//                break;
//            case enemystatetype.stagger:
//                _timer -= time.deltatime;
//                if (_timer < 0)
//                {
//                    _currentstate = enemystatetype.normal;
//                }
//                break;
//            case enemystatetype.dead:
//                break;
//        }
//    }

//    /// <summary>
//    /// 목표 방향으로 추적하는 함수
//    /// </summary>
//    public void follow()
//    {
//        // 재배치 체크
//        // 플레이어 캐릭터와의 거리 구하기
//        float dist = vector3.distance(_hero.transform.position, transform.position);
//        if (dist > _maxdist)
//        {
//            transform.position = _spawner.getspawnposition();
//        }

//        // 목표 방향 구하기
//        vector3 dir = (_hero.transform.position - transform.position).normalized;

//        // 목표 방향으로 이동
//        _mover.move(dir);
//    }

//    /// <summary>
//    /// 이동 정지 함수
//    /// </summary>
//    public void stop()
//    {
//        _mover.move(vector3.zero);
//    }

//    /// <summary>
//    /// 피격 함수
//    /// </summary>
//    /// <param name="damage">대미지</param>
//    public void takehit(float damage)
//    {
//        // 1) 로직 처리
//        _model.takedamage(damage);

//        if (_model.isalive == false) return;

//        // 2) 이동 정지
//        stop();

//        // 3) 피격 애니메이션 재생
//        _animatorhandler.handlehit();

//        // 4) 상태 변화
//        _currentstate = enemystatetype.stagger;

//        // 5) 일정 시간 후 자동으로 일반 상태 전환
//        _timer = 0.3f;
//    }

//    /// <summary>
//    /// 타겟을 공격하는 함수
//    /// </summary>
//    public void attacktarget()
//    {
//        _hero.takehit(_model.damage);
//    }

//    private void oncollisionenter2d(collision2d collision)
//    {
//        if (collision.gameobject.tag == "player")
//        {
//            attacktarget();
//        }
//    }


//    /// <summary>
//    /// 사망 함수
//    /// </summary>
//    public void die()
//    {
//        // 1) 사망 애니메이션 재생(애니메이터 트리거)
//        _animatorhandler.handledead();

//        // 2) 상태 변경
//        _currentstate = enemystatetype.dead;

//        // 3) 콜라이더 끄기
//        _collider.enabled = false;

//        // 4) 리지드바디 끄기
//        _rigid.simulated = false;

//        // 5) 1초 뒤 게임오브젝트 파괴 
//        invoke("remove", 1.0f);     // invoke(): 남용하면 안 되는 방식
//    }

//    /// <summary>
//    /// 게임에서 제거하는 함수
//    /// </summary>
//    public void remove()
//    {
//        destroy(gameobject);
//    }
//}