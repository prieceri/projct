using UnityEngine;

/*
1) 0Shovel, 1Gun 무기의 설정 데이터 수치를 잘 설정해 주세요. 

2) 각 설정 데이터에서 가져온 데이터가 레벨에 따라 실제 런타임 데이터 스탯에 적용되게 해 주세요.
*/


/// <summary>
/// 여러 종류의 무기들의 공통 기능을 포함하는 추상 부모 클래스
/// </summary>
public abstract class Weapon : MonoBehaviour
{
    [Header("----- 설정 데이터(공통) -----")]
    [SerializeField] protected WeaponData _data;

    [Header("----- 런타임 데이터(공통) -----")]
    [SerializeField] protected int _level;      // 현재 무기 레벨
    [SerializeField] protected float _damage;   // 공격력
    public int Level => _level;
    public float Damage => _damage;


    public abstract void Initialize();

    protected virtual void CalculateStats()
    {
        _damage = _data.GetStatData(_level).GetStat(WeaponStatType.Damage);
    }

    public virtual void Upgrade()
    {
        _level++;

        // 최초로 무기를 획득했을 경우(무기 레벨이 0이 되었을 경우)
        if(_level == 0)
        {
            Initialize();
        }
        else
        {
            CalculateStats();
        }
    }
}
